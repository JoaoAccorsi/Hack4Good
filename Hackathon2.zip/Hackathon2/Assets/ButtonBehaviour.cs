﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ButtonBehaviour : MonoBehaviour
{
    public Text showerText;
    public Text buttonText;
    public Text timeText;
    public float time = 0;
    public bool takingShower = false;
   

    public void OnButtonPress()
    {
        takingShower = !takingShower;   
    }
    public void OnStopPress()
    {
        takingShower = false;
        SceneManager.LoadScene("resultScene");

    }

    void Awake()
    {
        DontDestroyOnLoad(transform.gameObject);
    }

    private void Update()
    {
        if (takingShower == true)
        {
            showerText.text = "Taking a shower!";
            buttonText.text = "Pause";

            time += (Time.deltaTime * 30);
        }
        else
        {
            showerText.text = "Out from the shower!";
            buttonText.text = "Play";
        }
        DisplayTime(time);
    }
    void DisplayTime(float timeToDisplay)
    {
        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);
        float milis   = Mathf.FloorToInt((timeToDisplay - (minutes * 60) - seconds) * 100);

        timeText.text = string.Format("{0:00}:{1:00}:{2:00}", minutes, seconds, milis);
    }
}