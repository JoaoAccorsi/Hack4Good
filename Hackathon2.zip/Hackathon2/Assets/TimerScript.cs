﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TimerScript : MonoBehaviour
{
    public float time = 0;

    // Start is called before the first frame update
    void Update()
    {

        if (time < 0)
        {
            time += Time.deltaTime;
        }
    }
}
