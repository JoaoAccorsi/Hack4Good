﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class resultManagerScript : MonoBehaviour
{
    public float time;
    public float multiplier;
    public float cons;
    public float percent;
    public Text consText;
    public Text showerText;
    public Text percentText;
    public Sprite happy;
    public Sprite confused;
    public Sprite sad;
    public Image emoji;
    public Text messageText;
    public GameObject carinha;

    // Start is called before the first frame update
    void Start()
    {
        time = GameObject.Find("ButtonManager").GetComponent<ButtonBehaviour>().time;
        multiplier = GameObject.Find("configManager").GetComponent<configManagerScript>().multiplier;
        cons = time * multiplier;
        consText.text = string.Format("{0:0.0}L", cons);
        float minutes = Mathf.FloorToInt(time / 60);
        float seconds = Mathf.FloorToInt(time % 60);
        showerText.text = string.Format("Your shower time: {0:0}min {1:0}s", minutes, seconds);
        percent = cons * 100 / 110;
        percentText.text = string.Format("This bath represents {0:0.0}% of your daily water consumption", percent);
        if (cons <= 70){
            emoji.sprite = happy;
            messageText.text = "Congratulations! Your consuption is ideal";
        }
        if (cons > 70 & cons < 90)
        {
            emoji.sprite = confused;
            messageText.text = "Almost there! Try little harder, you can do it!";
        }
        if (cons >= 90)
        {
            emoji.sprite = sad;
            messageText.text = "Not good! Please keep working!";
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void onOKPress()
    {
        carinha = GameObject.Find("ButtonManager");
        Destroy(carinha);
        Destroy(GameObject.Find("configManager"));
        SceneManager.LoadScene("menuScene");
    }
}
